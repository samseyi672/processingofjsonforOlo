This  project  processes  a  large  json data  from the  url "http://files.olo.com/pizzas.json
The  logic is  in  the  class ""ProcessData"
the  entry  point  that  runs  the  program which  is the  class "ProcessOloJsonData"
It  is  an  eclipse  project.
All  the code  are  readable.
The processing logic is  very  fast and  can be  upscaled.
Upload  it  in  eclipse  or  any  IDE  and  run  it.
The code  is  very  accurate