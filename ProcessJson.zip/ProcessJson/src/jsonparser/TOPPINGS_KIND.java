package jsonparser;
public enum TOPPINGS_KIND {
	
}
